﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class NavigationForm : Form
    {
        public NavigationForm()
        {
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(300, 150); // координаты на экране
            InitializeComponent();
            this.FormClosing += NavigationForm_FormClosing;
        }

        private void NavigationForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Проходим по всем открытым дочерним формам
            foreach (Form openForm in Application.OpenForms)
            {
                // Опционально: исключаете главную форму из закрытия
                if (openForm != this)
                {
                    openForm.Close();
                }
            }
        }

        private void NavigationForm_Load(object sender, EventArgs e)
        {

        }
    }
}
